﻿using NUnit.Framework;

namespace WfdbCsharpWrapper.Test
{
    [TestFixture]
    public class CalibrationTests
    {
        /// <summary>
        /// A test for <see cref="CalibrationFile.Open"/>
        /// </summary>
        [Test]
        [Ignore]
        public void CalibrationFileOpenTest()
        {
            //string wfdbPath = Wfdb.WfdbPath;

            //Wfdb.WfdbPath = wfdbPath + " " + System.IO.Directory.GetCurrentDirectory();
            //CalibrationFile.Open("/data/dbcal");
        }
    }
}
