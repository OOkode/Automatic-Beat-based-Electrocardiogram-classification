#!/bin/bash

aclocal
automake
autoconf
