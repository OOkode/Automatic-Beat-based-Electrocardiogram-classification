Note    : The wfdb.dll file was compiled using gcc with Cygwin under Windows 7 x64.
version : 10.4.25 
Target  : 32 bit architecture

To see how to build the native windows version please visit this page :
http://physionet.org/physiotools/wfdb-windows-quick-start.shtml
 
Section : Making a native Windows version of the WFDB library